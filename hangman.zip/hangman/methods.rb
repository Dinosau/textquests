# Название
# Параметры
# Возвращаемое значение

#будет слово загаданное возвращать в виде массива его букв
def get_letters
  word = ARGV[0]

    if (word == nil || word == "")
      abort "Для игры введите загаданное слово в качестве аргумента при запуске программы"
    end

    return word.split("")
end


# возвращает введённую в игре букву
def get_user_input
    letter = ""
#если пользователь просто случайно нажал Enter,
# мы простим ему эту оплошность и спросим букву ещё раз
  while letter == "" do
    letter = STDIN.gets.chomp
  end

  return letter[0]
end


# # будет проверять
# есть ли буква из user_input среди букв в переменной letters  и добавлять её в один
# из массивов good_letters или bad_letters в зависимости от того, угадал пользователь или нет.
def check_input(user_input, letters, good_letters, bad_letters)
 if good_letters.include?(user_input) || bad_letters.include?(user_input)
    return 0
 elsif letters.include?(user_input)
        good_letters << user_input
        if good_letters.uniq.size == letters.uniq.size
          return 1
        else
          return 0
        end
 else
    bad_letters << user_input
    return -1
  end
end




def get_word_for_print(letters, good_letters)
  res = ""

  for item in letters do
    if good_letters.include?(item)
      res += item + " "
    else
      res += "__ "
    end
  end

  return res
end



# Вывести загаданное слово, отметив в нём прочерками закрытые (ещё не отгаданные буквы), как в «Поле чудес», что-то типа
# _ о л о _ о
# Показать игроку количество ошибок и уже названные буквы, которых нет в слове (те, что были названы и оказались в слове, уже указаны в первом пункте).
# Если мы совершили семь ошибок, то метод должен написать игроку о том, что тот проиграл и наоборот, если слово отгадано, то этот метод должен поздравить игрока с победой.
def print_status(letters, good_letters, bad_letters, errors)
  puts "\nСлово: " + get_word_for_print(letters, good_letters)
  puts "Ошибки (#{errors}): #{bad_letters.join(", ")}"

  if errors >= 7
    abort "Вы проиграли :("
  else
    if letters.uniq.size == good_letters.uniq.size
      abort "Поздравляем, вы выиграли!"
    else
      puts "Попыток: " + (7 - errors).to_s
    end
  end
end




# чистит экран в консоли
def cls
  system "clear" or system "cls"
end

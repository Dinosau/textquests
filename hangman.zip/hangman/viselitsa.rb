require "./methods.rb"

errors = 0
good_letters = []
bad_letters = []

letters = get_letters   #условие игры:загаданное слово. В переменной хранится массив его букв

cls

while errors != 8 do
  print_status(letters, good_letters, bad_letters, errors)
  puts "\nВведите букву"
  user_input = get_user_input
  result = check_input(user_input, letters, good_letters, bad_letters)
    if result == -1
      errors += 1
    end
end

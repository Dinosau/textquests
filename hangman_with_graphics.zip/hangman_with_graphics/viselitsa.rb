require "./game.rb"
require "./result_printer.rb"

word = ARGV[0]
  if (Gem.win_platform? && ARGV[0])
    word = word.dup
      .force_encoding("IBM866")
      .encode("IBM866", "cp1251")
      .encode("UTF-8")
  end

# создадим по экземпляру каждого класса.
printer = ResultPrinter.new
game = Game.new(word)

while game.status != -1 ||  game.status != 1 do
  printer.print_status(game)
  game.ask_next_letter
end






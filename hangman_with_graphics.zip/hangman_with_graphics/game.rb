class Game

  def initialize(word)
    @letters = get_letters(word)
    @errors = 0
    @good_letters = []
    @bad_letters = []
    @status = 0
  end
# Так как метод get_letters принадлежит тому же классу Game,
# в конструкторе нет необходимости писать Game.get_letters,
# достаточно написать просто get_letters. Это верно для всех методов класса Game,
# вызываемых из других методов класса Game
  def status
    return @status
  end

  def errors
    return @errors
  end

  def letters
    return @letters
  end

  def good_letters
    return @good_letters
  end

  def bad_letters
    return @bad_letters
  end



  def get_letters(word)
    if (word == nil || word == "")
      abort "Для игры введите загаданное слово в качестве аргумента при запуске программы"
    end

    return word.split("")
  end



  def ask_next_letter
    puts "Введите следующую букву"
    letter = ""
    while letter == "" do
      letter = STDIN.gets.encode("UTF-8").chomp
    end
    next_step(letter)
  end


  def next_step(bukva) # данные он берёт не из параметров, а из полей класса.

    if @status == -1 || @status == 1
      return
    end

    if @good_letters.include?(bukva) || @bad_letters.include?(bukva)
      return
    end

    if @letters.include?(bukva)
       @good_letters << bukva
      if @good_letters.uniq.sort == @letters.uniq.sort
         @status = 1
      end
    else
      @bad_letters << bukva
      @errors += 1
      if @errors >= 7
         @status = -1
      end
    end
  end
end
